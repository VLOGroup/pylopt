import unittest
import torch
import os

from torch import dtype

from bilevel_optimisation.potential.Potential import StudentTPotential
from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.fields_of_experts.FieldsOfExperts import FieldsOfExperts

class TestFieldsOfExperts(unittest.TestCase):

    def setUp(self):
        self.potential = StudentTPotential()
        self.data_root_path = '/home/florianthaler/Documents/research/stochastic_bilevel_optimisation/data/pretrained_models'


    def test_forward(self):
        filters = torch.load(os.path.join(self.data_root_path, 'foe_filters_7x7_chen-ranftl-pock_2014.pt'))
        filters = filters.to(dtype=torch.float64)
        filters = filters * 255
        filters_spec = ParamSpec(filters, trainable=False)
        filter_weights_spec = ParamSpec(torch.ones(filters.shape[0], dtype=torch.float64) / 1000, trainable=True,
                                        projection=lambda z: torch.clamp(z, min=0.00001))

        self.model = FieldsOfExperts(self.potential, filters_spec, filter_weights_spec)
        self.model.cuda()

        x = torch.ones(1, 1, 10, 10, dtype=torch.float64).cuda()
        y = self.model(x)

        self.assertAlmostEqual(1.6744e-11, y.detach().cpu().item(), delta=1e-12)
