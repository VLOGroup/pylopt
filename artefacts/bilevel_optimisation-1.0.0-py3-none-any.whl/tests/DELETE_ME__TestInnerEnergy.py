import unittest
import torch
import cv2
import os

from bilevel_optimisation.energy.InnerEnergy import FoEDenoising
from bilevel_optimisation.measurement_model.MeasurementModel import MeasurementModel
from bilevel_optimisation.fields_of_experts.FieldsOfExperts import FieldsOfExperts
from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.data.OptimiserSpec import OptimiserSpec
from bilevel_optimisation.potential.Potential import StudentTPotential
from bilevel_optimisation.optimiser.NAGOptimiser import NAGOptimiser
from bilevel_optimisation.optimiser.StoppingCriterion import EarlyStopping
from bilevel_optimisation.factories.BuildFactory import build_optimiser_factory, build_prox_map_factory

class TestFoEDenoising(unittest.TestCase):

    def setUp(self):

        self.noise_level = 0.1
        self.dtype = torch.float64
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

        image_data_root_path = '/home/florianthaler/Documents/data/image_data/debug/'
        image_clean = cv2.imread(os.path.join(image_data_root_path, 'portrait_lady.png'), cv2.IMREAD_GRAYSCALE)
        image_clean = image_clean[0: 64, 0: 64] / 255
        self.image_tensor_clean = torch.tensor(image_clean).unsqueeze(dim=0).unsqueeze(dim=0)
        self.image_tensor_clean = self.image_tensor_clean.to(device=self.device)
        self.image_tensor_noisy = self.image_tensor_clean + self.noise_level * torch.randn_like(self.image_tensor_clean)


        model_data_root_path = '/home/florianthaler/Documents/research/stochastic_bilevel_optimisation/data/pretrained_models'
        filters = torch.load(os.path.join(model_data_root_path, 'foe_filters_7x7_chen-ranftl-pock_2014.pt'))
        filters = filters.to(dtype=self.dtype)
        filters = filters * 255
        self.filters_spec = ParamSpec(filters, trainable=False)
        self.filter_weights_spec = ParamSpec(torch.ones(filters.shape[0], dtype=torch.float64) / 1000, trainable=True,
                                             projection=lambda z: torch.clamp(z, min=0.00001))

        self.potential = StudentTPotential()

        self.lam = 0.005

        prox_map = lambda x, y, tau: (tau * y + x) / (1 + tau)
        prox_map_factory = build_prox_map_factory(prox_map)
        optimiser_spec = OptimiserSpec(optimiser_class=NAGOptimiser, optimiser_params={'beta': 0.71},
                                             stopping=EarlyStopping(max_num_iterations=1000, rel_tol=1e-6),
                                             prox_map_factory=prox_map_factory)
        self.optimiser_factory = build_optimiser_factory(optimiser_spec)
    def test_hvp_mixed(self):


        measurement_model = MeasurementModel(x_clean=self.image_tensor_clean, operator=torch.nn.Identity(),
                                             noise_std=self.noise_level)
        regulariser = FieldsOfExperts(self.potential, self.filters_spec, self.filter_weights_spec)

        energy = FoEDenoising(measurement_model, regulariser, self.lam, self.optimiser_factory)
        energy.to(device=self.device)

        x_denoised = torch.load(os.path.join('/home/florianthaler/Downloads', 'debug_denoised.pt'))
        lagrangian_multiplier = torch.load(os.path.join('/home/florianthaler/Downloads', 'debug_lagrangian.pt'))

        hvp = energy.hvp_mixed(x_denoised, lagrangian_multiplier)


        print('blöa')



