import unittest
import torch

from bilevel_optimisation.optimiser.NAGOptimiser import NAGOptimiser

class TestNAGOptimiser(unittest.TestCase):

    def setUp(self):
        self._max_num_iterations = 100
        self._test_accuracy = 1e-5

    def test_quadratic(self):

        objective_func = lambda z: torch.sum(z ** 2)
        x = torch.nn.Parameter(torch.tensor([1.23, 4.56]), requires_grad=True)

        optim = NAGOptimiser([x])
        x.proj = lambda z: torch.clamp(z, 0.00001)

        for i in range(0, self._max_num_iterations):

            def closure():
                optim.zero_grad()
                with torch.enable_grad():
                    loss = objective_func(x)
                    loss.backward()
                return loss

            optim.step(closure)

        self.assertAlmostEqual(torch.sum(x ** 2).detach().cpu().item(), 0.0, delta=self._test_accuracy)

    def test_quadratic_fixed_alpha(self):
        objective_func = lambda z: torch.sum(z ** 2)
        x = torch.nn.Parameter(torch.tensor([1.23, 4.56]), requires_grad=True)

        optim = NAGOptimiser([x], alpha=0.001)
        x.proj = lambda z: torch.clamp(z, 0.00001)

        for i in range(0, self._max_num_iterations):
            def closure():
                optim.zero_grad()
                with torch.enable_grad():
                    loss = objective_func(x)
                    loss.backward()
                return loss

            optim.step(closure)

        self.assertAlmostEqual(torch.sum(x ** 2).detach().cpu().item(), 0.0, delta=self._test_accuracy)


