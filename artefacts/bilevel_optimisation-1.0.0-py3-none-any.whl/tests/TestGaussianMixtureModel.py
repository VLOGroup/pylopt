from unittest import TestCase
import torch

from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.gaussian_mixture_model.GaussianMixtureModel import GaussianMixtureModel

class TestGaussianMixtureModel(TestCase):

    def setUp(self):
        torch.manual_seed(123)

        num_components = 10
        weights = torch.rand(num_components)
        weights_spec = ParamSpec(weights, trainable=False)

        self._gmm = GaussianMixtureModel(num_components=num_components, box_lower=-1.0, box_upper=1.0,
                                         weights_spec=weights_spec)


    def forward_expected(self, x: torch.Tensor) -> torch.Tensor:
        y_expected = torch.zeros_like(x)
        for k in range(0, 28):
            for l in range(0, 28):
                for j in range(0, self._gmm._num_components):
                    tmp = -0.5 * ((x[0, 0, k, l] - self._gmm.centers[j]) ** 2) / self._gmm.variance
                    y_expected[0, 0, k, l] += (self._gmm._weights[j]
                                               * (1 / torch.sqrt(2 * torch.pi * self._gmm.variance))
                                               * torch.exp(tmp))
        return y_expected

    def forward_expected_alternative(self, x: torch.Tensor) -> torch.Tensor:
        args = (-0.5 * ((x.unsqueeze(dim=-1) - self._gmm.centers.reshape(1, -1)) ** 2)
                / self._gmm.variance)
        mixtures = torch.exp(args) / torch.sqrt(2 * torch.pi * self._gmm.variance)
        return torch.sum(mixtures * self._gmm._weights[None, None, None, :], dim=-1)

    def test_forward(self):
        x = torch.rand(1, 1, 28, 28)
        y_expected = self.forward_expected(x)
                # y_expected_ = self.forward_expected_alternative(x)
        y = self._gmm(x)

        diff_norm = torch.linalg.norm(y - y_expected)
        self.assertAlmostEqual(diff_norm, torch.zeros(1), delta=1e-5)

    def forward_negative_log_expected(self, x: torch.Tensor) -> torch.Tensor:
        return -torch.log(self.forward_expected(x))

    def test_forward_negative_log(self):
        x = torch.rand(1, 1, 28, 28)
        y_expected = self.forward_negative_log_expected(x)
        y = self._gmm.forward_negative_log(x)

        diff_norm = torch.linalg.norm(y - y_expected)
        self.assertAlmostEqual(diff_norm, torch.zeros(1), delta=1e-5)
