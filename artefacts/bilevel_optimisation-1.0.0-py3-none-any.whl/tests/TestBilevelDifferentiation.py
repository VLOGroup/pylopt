import unittest
import torch
import os
import cv2
from typing import Callable, List

from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.data.OptimiserSpec import OptimiserSpec
from bilevel_optimisation.optimiser.NAGOptimiser import NAGOptimiser
from bilevel_optimisation.optimiser.StoppingCriterion import EarlyStopping
from bilevel_optimisation.factories.BuildFactory import build_optimiser_factory, build_prox_map_factory
from bilevel_optimisation.measurement_model.MeasurementModel import MeasurementModel
from bilevel_optimisation.fields_of_experts.FieldsOfExperts import FieldsOfExperts
from bilevel_optimisation.potential.Potential import StudentTPotential
from bilevel_optimisation.energy.InnerEnergy import FoEDenoising, InnerEnergy
from bilevel_optimisation.bilevel.Bilevel import BilevelDifferentiation
from bilevel_optimisation.solver.CGSolver import CGSolver

class TestBilevelDifferentiation(unittest.TestCase):

    def setUp(self):

        torch.manual_seed(123)

        self.noise_level = 0.1
        self.dtype = torch.float64
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

        image_data_root_path = '/home/florianthaler/Documents/data/image_data/debug/'
        image_clean = cv2.imread(os.path.join(image_data_root_path, 'portrait_lady.png'), cv2.IMREAD_GRAYSCALE)
        image_clean = image_clean[0: 64, 0: 64] / 255
        self.image_tensor_clean = torch.tensor(image_clean).unsqueeze(dim=0).unsqueeze(dim=0)
        self.image_tensor_clean = self.image_tensor_clean.to(device=self.device, dtype=self.dtype)

        image_noisy = cv2.imread(os.path.join(image_data_root_path, 'portrait_lady_noisy.png'), cv2.IMREAD_GRAYSCALE)
        image_noisy = image_noisy / 255
        self.image_tensor_noisy = torch.tensor(image_noisy).unsqueeze(dim=0).unsqueeze(dim=0)
        self.image_tensor_noisy = self.image_tensor_noisy.to(device=self.device, dtype=self.dtype)

        model_data_root_path = '/home/florianthaler/Documents/research/stochastic_bilevel_optimisation/data/pretrained_models'
        filters = torch.load(os.path.join(model_data_root_path, 'foe_filters_7x7_chen-ranftl-pock_2014.pt'))
        filters = filters.to(dtype=self.dtype)
        filters = filters * 255
        self.filters_spec = ParamSpec(filters, trainable=False)
        self.filter_weights_spec = ParamSpec(torch.ones(filters.shape[0], dtype=self.dtype) / 1000, trainable=True,
                                             projection=lambda z: torch.clamp(z, min=0.00001))
        self.potential = StudentTPotential()

        prox_map = lambda x, y, tau: (tau * y + x) / (1 + tau)
        prox_map_factory = build_prox_map_factory(prox_map)
        optimiser_spec = OptimiserSpec(optimiser_class=NAGOptimiser, optimiser_params={'beta': 0.71},
                                             stopping=EarlyStopping(max_num_iterations=1000, rel_tol=1e-6),
                                             prox_map_factory=prox_map_factory)
        self.optimiser_factory = build_optimiser_factory(optimiser_spec)

        self.gradient_func = BilevelDifferentiation

    @staticmethod
    def compute_expected_gradient(inner_energy: InnerEnergy, x_clean: torch.Tensor, x_noisy,
                                  solver: CGSolver, loss_func: Callable) -> List[torch.Tensor]:

        with torch.no_grad():
            x_denoised = inner_energy.argmin(x_noisy)

        with torch.enable_grad():
            x_ = x_denoised.detach().clone()
            x_.requires_grad = True
            loss = loss_func(x_, x_clean)
        grad_loss = torch.autograd.grad(outputs=loss, inputs=x_)[0].detach()

        xx = x_denoised.detach().clone()
        lin_operator = lambda z: inner_energy.hvp_state(xx, z)
        result_lagrangian = solver.solve(lin_operator, -grad_loss)

        grad = inner_energy.hvp_mixed(x_denoised.detach(), result_lagrangian.solution)
        return grad

    def _test_gradient_flow(self):
        measurement_model = MeasurementModel(x_clean=self.image_tensor_clean, operator=torch.nn.Identity(),
                                             noise_std=self.noise_level)
        regulariser = FieldsOfExperts(self.potential, self.filters_spec, self.filter_weights_spec)

        inner_energy = FoEDenoising(measurement_model, regulariser, 0.005, self.optimiser_factory)
        inner_energy.to(device=self.device)
        loss_func = lambda x1, x2: 0.5 * torch.sum((x1 - x2) ** 2)

        solver = CGSolver(500, 1e-6, 1e-6)

        expected_gradient = self.compute_expected_gradient(inner_energy, self.image_tensor_clean,
                                                           self.image_tensor_noisy, solver, loss_func)

        trainable_parameters = [p for p in regulariser.parameters() if p.requires_grad]
        with torch.enable_grad():
            x_ = self.image_tensor_clean.clone()
            x_.requires_grad = True
            loss = self.gradient_func.apply(inner_energy, x_, loss_func, solver,
                                            *trainable_parameters)
            loss.backward()

        grad_diff_norm_list = [torch.linalg.norm(grad - p.grad).detach().cpu().numpy()
                               for grad, p in zip(expected_gradient, trainable_parameters)]

        self.assertLessEqual(max(grad_diff_norm_list), 1e-7)

    def test_gradient_computation(self):

        data_root_dir = '/home/florianthaler/Documents/research/stochastic_bilevel_optimisation/data/unittests/'
        x_clean = torch.load(os.path.join(data_root_dir, 'debug_sample_clean.pt'))
        x_denoised = torch.load(os.path.join(data_root_dir, 'debug_sample_denoised.pt'))
        lagrangian_expected = torch.load(os.path.join(data_root_dir, 'debug_lagrangian.pt'))
        grad_expected = torch.load(os.path.join(data_root_dir, 'debug_gradient.pt'))


        measurement_model = MeasurementModel(x_clean=x_clean, operator=torch.nn.Identity(),
                                             noise_std=self.noise_level)
        regulariser = FieldsOfExperts(self.potential, self.filters_spec, self.filter_weights_spec)

        inner_energy = FoEDenoising(measurement_model, regulariser, 0.005, self.optimiser_factory)
        inner_energy.to(device=self.device)
        loss_func = lambda x1, x2: 0.5 * torch.sum((x1 - x2) ** 2)

        solver = CGSolver(500, 1e-6, 1e-6)

        trainable_parameters = [p for p in regulariser.parameters() if p.requires_grad]
        with torch.enable_grad():
            x_ = x_clean.detach().clone()
            x_.requires_grad = True
            loss = self.gradient_func.apply(inner_energy, x_, loss_func, solver,
                                            *trainable_parameters)
            loss.backward()

        grad_diff_norm = torch.linalg.norm(grad_expected - trainable_parameters[0].grad).detach().cpu().numpy()
        self.assertLessEqual(grad_diff_norm, 1e-7)

