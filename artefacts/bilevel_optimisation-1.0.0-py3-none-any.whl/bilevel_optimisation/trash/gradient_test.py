import torch

from bilevel_optimisation.energy.InnerEnergy import FoEDenoising
from bilevel_optimisation.fields_of_experts.FieldsOfExperts import FieldsOfExperts
from bilevel_optimisation.measurement_model.MeasurementModel import MeasurementModel
from bilevel_optimisation.potential.Potential import StudentTPotential
from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.data.OptimiserSpec import OptimiserSpec
from bilevel_optimisation.optimiser.NAGOptimiser import NAGOptimiser
from bilevel_optimisation.optimiser.StoppingCriterion import EarlyStopping
from bilevel_optimisation.factories.BuildFactory import (build_optimiser_factory, build_solver_factory,
                                                         build_prox_map_factory)
x = torch.ones(1, 1, 64, 64)
noise_level = 0.1
lam = 0.005

measurement_model = MeasurementModel(x, torch.nn.Identity(), noise_level)
potential = StudentTPotential()
filters = torch.load('/home/florianthaler/Documents/data/models/foe_models/foe_filters_7x7_chen-ranftl-pock_2014.pt')
filters = filters * 255
filters_spec = ParamSpec(filters, trainable=False)
filter_weights_spec = ParamSpec(torch.ones(filters.shape[0]) / 1000, trainable=True,
                                projection=lambda z: torch.clamp(z, min=0.00001))
regulariser = FieldsOfExperts(potential, filters_spec, filter_weights_spec)
prox_map = lambda x, y, tau: (tau * y + x) / (1 + tau)
prox_map_factory = build_prox_map_factory(prox_map)
optimiser_spec_inner = OptimiserSpec(optimiser_class=NAGOptimiser,
                                     optimiser_params={'beta': 0.71, 'lip_const_default': 1e2},
                                     stopping=EarlyStopping(max_num_iterations=1000, rel_tol=1e-5),
                                     prox_map_factory=prox_map_factory)
optimiser_factory_inner = build_optimiser_factory(optimiser_spec_inner)
inner_energy = FoEDenoising(measurement_model, regulariser, lam, optimiser_factory_inner)
inner_energy.to(dtype=torch.float64, device=torch.device('cuda:0'))

x = x.to(dtype=torch.float64, device=torch.device('cuda:0'))


with torch.enable_grad():
    x_ = x.detach().clone()
    x_.requires_grad = True

    e = inner_energy(x_)

    de_dx = torch.autograd.grad(inputs=x_, outputs=e, create_graph=True, retain_graph=True)

d2e_mixed = torch.autograd.grad(inputs=[p for p in inner_energy.parameters() if p.requires_grad],
                                outputs=e, create_graph=True, retain_graph=True)

z1 = d2e_mixed[0].clone()

with torch.enable_grad():
    xx_ = x.detach().clone()
    xx_.requires_grad = True
    r = inner_energy._regulariser(xx_)

    dr_dx = torch.autograd.grad(inputs=xx_, outputs=r, create_graph=True, retain_graph=True)

d2e_mixed_ = torch.autograd.grad(inputs=[p for p in inner_energy.parameters() if p.requires_grad],
                                 outputs=r, create_graph=True, retain_graph=True)

z2 = lam * d2e_mixed_[0].clone()

print('now what ?!?')
