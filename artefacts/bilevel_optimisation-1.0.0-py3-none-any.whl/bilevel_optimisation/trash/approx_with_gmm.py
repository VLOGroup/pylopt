import torch
import numpy as np
from matplotlib import pyplot as plt

from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.projection.ParameterProjections import unit_simplex_projection
from bilevel_optimisation.gaussian_mixture_model.GaussianMixtureModel import GaussianMixtureModel


def func(t):
    return 1 / (torch.pi * (1 + t ** 2))

torch.manual_seed(123)

num_components = 73
box_lower = -3
box_upper = 3
weights_spec = ParamSpec(torch.rand(num_components), True)
gmm = GaussianMixtureModel(num_components, box_lower, box_upper, weights_spec)

for name, param in gmm.named_parameters():
    print(f"{name} -> shape: {param.shape}")

# gmm.variance.copy_(0.25)

optimiser = torch.optim.Adam(gmm.parameters())

t_array = torch.linspace(-box_lower, box_upper, 1001)


for k in range(0, 5000):

    # l = np.random.randint(low=50, high=101)
    # n = 2 * l + 1

    # data = torch.from_numpy(np.random.standard_cauchy(size=1000)).to(dtype=torch.float32)

    optimiser.zero_grad()

    loss = torch.sum((func(t_array) - gmm(t_array)) ** 2) # + 0.15 * (func(torch.zeros(1)) - gmm(torch.zeros(1))) ** 2
    # loss = torch.mean(-torch.log(gmm(data) + 1e-11))
    loss.backward()

    optimiser.step()

    for group in optimiser.param_groups:
        for p in group['params']:
            if not p.requires_grad:
                continue
            # p.data[num_components // 2 + 1 ::] = torch.flip(p.data[0 : num_components // 2], dims=[0])
            # p.data[num_components // 2 ::] = torch.flip(p.data[0 : num_components // 2], dims=[0])
            # p.data.copy_(torch.nn.functional.softmax(p.data))
            p.data.copy_(unit_simplex_projection(p.data))
            # p.data.copy_(torch.clamp(p.data, min=0.0001))

    if (k + 1) % 100 == 0:
        l1_norm = torch.sum(torch.cat([p for p in gmm.parameters() if p.requires_grad]))
        print('iter {:d}: loss = {:.5f}, l1 norm of weights = {:.5f}'.format(k + 1, loss.detach().cpu().item(), l1_norm.detach().cpu().item()))


# data_dir_path = '/home/florianthaler/Documents/research/stochastic_bilevel_optimisation/data/'
# torch.save(gmm.state_dict(), os.path.join(data_dir_path, 'pretrained_models', 'gmm.pt'))

tt = torch.linspace(-3, 3, 101)
# tt = t_array
fig = plt.figure()
ax_1 = fig.add_subplot(1, 2, 1)
ax_1.plot(tt.detach().cpu(), func(tt).detach().cpu().numpy(), color='blue')
ax_1.plot(tt.detach().cpu(), gmm(tt).detach().cpu().numpy(), color='orange')

ax_2 = fig.add_subplot(1, 2, 2)
ax_2.plot(tt.detach().cpu(), -torch.log(func(tt)).detach().cpu().numpy(), color='blue')
ax_2.plot(tt.detach().cpu(), -torch.log(gmm(tt)).detach().cpu().numpy(), color='orange')
plt.show()