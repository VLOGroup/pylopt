from platform import architecture

import torch

from bilevel_optimisation.data.ParamSpec import ParamSpec
from bilevel_optimisation.potential import GaussianMixture, StudentT

weights_spec = ParamSpec(torch.ones(12), trainable=True)
pot = GaussianMixture(num_components=12, box_lower=-1.0, box_upper=1.0, num_filters=5, weights_spec=weights_spec)

pot_ = StudentT()
s_ = pot_.state_dict()

# torch.save({'state_dict': pot.state_dict(),
#             'architecture': {'num_components': 12,
#                              'box_lower': -1.0,
#                              'box_upper': 1.0,
#                              'num_filters': 5
#                              }
#             }, 'potential.pt')
# model_data = torch.load('potential.pt')
# arch = model_data['architecture']
# arch['weights_spec'] = ParamSpec(torch.ones(12), trainable=True)

# pot = GaussianMixture(**arch)
# pot.load_state_dict(model_data['state_dict'])

s = pot.state_dict()

print('bla')
# pot.load_state_dict()


