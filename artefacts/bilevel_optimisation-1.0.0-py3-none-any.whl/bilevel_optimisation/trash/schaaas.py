import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from scipy.stats import t

# Step 1: Generate data from Student's t-distribution (df=1)
np.random.seed(42)
n_samples = 10000
data = t(df=1).rvs(size=n_samples).reshape(-1, 1)

# Step 2: Fit Gaussian Mixture Model
n_components = 25  # You can increase this to better approximate heavy tails
gmm = GaussianMixture(n_components=n_components, covariance_type='full', random_state=42, means_init=np.linspace(-2, 2, n_components).reshape(-1, 1))
gmm.fit(data)

# Step 3: Plotting
x = np.linspace(-2, 2, 1000).reshape(-1, 1)
logprob = gmm.score_samples(x)
pdf = np.exp(logprob)

# True Cauchy pdf
true_pdf = t(df=1).pdf(x)

plt.figure(figsize=(10,6))
# plt.hist(data, bins=100, density=True, alpha=0.5, color='gray', label='Sampled Data')
plt.plot(x, true_pdf, 'r-', lw=2, label='True Cauchy (t df=1)')
plt.plot(x, pdf, 'b--', lw=2, label=f'GMM (n_components={n_components})')

# plt.scatter(gmm.means_, 0.01 * np.ones_like(gmm.means_))
plt.legend()
plt.title('Fitting a Gaussian Mixture to a Student-t Distribution (df=1)')
plt.show()