import torch
from matplotlib import pyplot as plt
import numpy as np
from scipy.optimize import fsolve

from bilevel_optimisation.projection.ParameterProjections import unit_simplex_projection

def normal_pdf(x, sig_sq, mu):
    return np.exp((-0.5 / sig_sq) * ((x - mu)  ** 2)) / np.sqrt(2 * np.pi * sig_sq)

def objective_func(t, d, eps):
    return (np.exp((-0.5 / t) * (0.5 * d) ** 2) / np.sqrt(2 * np.pi * t) - eps) ** 2 + (t - 0.5 * d)**2

def find_variance(mode_dist: float):
    eps = 1e-1
    root = fsolve(lambda z: objective_func(z, mode_dist, eps), 0.25 * mode_dist)

    print(root)
    print(objective_func(root, mode_dist, eps))

    return root

box_lower = -2.0
box_upper = 2.0
num_components = 125
mode_list = np.linspace(box_lower, box_upper, num_components)
mode_dist = (box_upper - box_lower) / (num_components - 1)

# sig_sq = find_variance(mode_dist)
# eps = 1e-1
# sig = (1 / (np.sqrt(2 * np.pi) * eps)) * (1 - 0.125 * (mode_dist ** 2))
# sig_sq = sig ** 2

sig_sq = (2 * (box_upper - box_lower) / (num_components - 1)) ** 2

fig = plt.figure()
ax1 = fig.add_subplot(1, 2, 1)
ax2 = fig.add_subplot(1, 2, 2)

t = np.linspace(-3, 3, 101)
# y = normal_pdf(t, sig_sq, -1.0)
# ax.plot(t, y)

weights = 1 / (1 + np.array(mode_list) ** 2)
weights_ = np.sqrt(2 * np.pi * sig_sq) / (np.pi * (1 + 1 * np.array(mode_list) ** 2))

weights_proj_ = np.exp(weights_)/sum(np.exp(weights_))
weights_proj__ = unit_simplex_projection(torch.tensor(weights_)).detach().cpu().numpy()


y_list = [normal_pdf(t, sig_sq, mode_list[i]) for i in range(0, num_components)]
y_array = np.array(y_list)


y = np.sum(y_array * weights[:, None], axis=0)
y_ = np.sum(y_array * weights_[:, None], axis=0)
ax1.plot(t, y)
ax1.plot(t, y_)

ax2.plot(t, np.sum(y_array * weights_proj_[:, None], axis=0), color='green')
ax2.plot(t, np.sum(y_array * weights_proj__[:, None], axis=0))
ax2.plot(t, 1 / (np.pi * (1 + t ** 2)), color='cyan')
# for i in range(0, 5):
#
#     y =  normal_pdf(t, sig_sq, mode_list[i])
#     ax1.plot(t, y)
#


plt.show()


#
# sig_sq = 0.01

# y = normal_pdf(t, sig_sq, 0)
#
# delta = 0.001
# xx = np.sqrt(-2 * sig_sq * np.log(delta * np.sqrt(2 * np.pi * sig_sq)))
# yy = normal_pdf(xx, sig_sq, 0)
#
# print(xx)
# print(yy)
#
# ax.plot(t, y)
# ax.plot(xx, yy, marker='x', color='red')
#
#
# y1 = normal_pdf(t, sig_sq, 2 * xx)
# y2 = normal_pdf(t, root, 2 * xx)
# ax.plot(t, y1, color='magenta')
# ax.plot(t, y2, color='cyan')
#
# plt.show()