from torch.utils.data import DataLoader

from bilevel_optimisation.dataset.ImageDataset import ImageDataset
from bilevel_optimisation.utils.DatasetUtils import collate_function

train_data_root_dir = '/home/florianthaler/Documents/data/image_data/BSDS300/images/train'
train_image_dataset = ImageDataset(root_path=train_data_root_dir)

batch_size = 32
train_loader = DataLoader(train_image_dataset, batch_size=batch_size, shuffle=True,
                          collate_fn=lambda x: collate_function(x, crop_size=64))




for idx, batch in enumerate(train_loader):
    print(idx)

    if idx > 100:
        break
